import tensorflow as tf
import tensorflow_hub as hub
from PIL import Image
import numpy as np
from tensorflow.keras.models import load_model
import cv2

# Load class names
with open("food-101/meta/classes.txt") as f:
    class_names = [line.strip() for line in f.readlines()]

# Load the Food-101 model
model = load_model("model_food_101.h5")

def preprocess_image(image_path: str, target_size=(224, 224)):
    img = Image.open(image_path)
    img = img.resize(target_size)
    img_array = np.array(img) / 255.0
    return img_array

def segment_food(image_path: str):
    # Read the image
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Could not read the image file")
    
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Apply bilateral filter to preserve edges while removing noise
    filtered = cv2.bilateralFilter(gray, 9, 75, 75)
    
    # Apply adaptive thresholding with optimized parameters
    thresh = cv2.adaptiveThreshold(
        filtered,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV,
        15,  # Block size increased for better segmentation
        5    # C constant adjusted for better contrast
    )
    
    # Apply morphological operations to clean up the segmentation
    kernel = np.ones((5,5), np.uint8)
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    
    # Find contours
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # Filter contours by area and aspect ratio
    min_area = 2000  # Increased minimum area
    max_area = img.shape[0] * img.shape[1] * 0.8  # Maximum area (80% of image)
    food_segments = []
    
    for contour in contours:
        area = cv2.contourArea(contour)
        if min_area < area < max_area:
            x, y, w, h = cv2.boundingRect(contour)
            aspect_ratio = float(w)/h
            # Filter based on aspect ratio (typical food items are not too elongated)
            if 0.2 < aspect_ratio < 5:
                food_segments.append((x, y, w, h))
    
    return img_rgb, food_segments

def recognize_food(image_path: str):
    # Segment the image into potential food items
    original_img, segments = segment_food(image_path)
    recognized_foods = []
    
    # Process each segment
    for x, y, w, h in segments:
        # Extract the segment with padding
        padding = 10
        x1 = max(0, x - padding)
        y1 = max(0, y - padding)
        x2 = min(original_img.shape[1], x + w + padding)
        y2 = min(original_img.shape[0], y + h + padding)
        segment = original_img[y1:y2, x1:x2]
        
        # Convert to PIL Image
        segment_pil = Image.fromarray(segment)
        
        # Save segment temporarily
        temp_path = f"temp_segment_{x}_{y}.jpg"
        segment_pil.save(temp_path)
        
        # Preprocess and predict
        img_array = preprocess_image(temp_path)
        img_array = np.expand_dims(img_array, axis=0).astype(np.float32)
        
        # Get predictions
        predictions = model(img_array)
        top_indices = np.argsort(predictions[0])[::-1][:3]  # Get top 3 predictions
        
        # Check if any prediction has high confidence
        for idx in top_indices:
            confidence = predictions[0][idx]
            if confidence > 0.65:  # Increased confidence threshold
                recognized_foods.append({
                    'name': class_names[idx],
                    'confidence': float(confidence),
                    'position': (x, y, w, h)
                })
                break  # Only take the highest confidence prediction for this segment
        
        # Clean up temporary file
        import os
        os.remove(temp_path)
    
    # Sort by confidence
    recognized_foods.sort(key=lambda x: x['confidence'], reverse=True)
    
    # Return unique food items (avoid duplicates)
    unique_foods = []
    seen_positions = set()
    
    for food in recognized_foods:
        x, y, w, h = food['position']
        # Check if this food item overlaps significantly with any previously seen item
        is_duplicate = False
        for seen_x, seen_y, seen_w, seen_h in seen_positions:
            # Calculate overlap
            overlap_x = max(0, min(x + w, seen_x + seen_w) - max(x, seen_x))
            overlap_y = max(0, min(y + h, seen_y + seen_h) - max(y, seen_y))
            overlap_area = overlap_x * overlap_y
            segment_area = w * h
            if overlap_area > 0.4 * segment_area:  # Reduced overlap threshold to 40%
                is_duplicate = True
                break
        
        if not is_duplicate:
            unique_foods.append(food['name'])
            seen_positions.add((x, y, w, h))
    
    return unique_foods


